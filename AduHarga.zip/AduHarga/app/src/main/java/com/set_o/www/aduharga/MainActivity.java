package com.set_o.www.aduharga;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    private void displaySelectedScreen(int id){
        android.support.v4.app.Fragment fragment = null;

        switch (id) {
            case R.id.nav_profile:
                fragment = new ProfileFragment();
                break;

            case R.id.nav_about_app:
                fragment = new AboutAppFragment();
                break;

            case R.id.nav_about_us:
                fragment = new AboutUsFragment();
                break;

            case R.id.nav_calls:
                fragment = new CallFragment();
                break;

            case R.id.nav_feed:
                fragment = new FeedFragment();
                break;

            case R.id.nav_ads:
                fragment = new AdsFragment();
                break;

/*  AI SUGAN BISA SAKAIALIAN ANJ BOTTOM NAVBAR JEUNG NAV DRAWERNA.......

            case R.id.nav_rumah:
                fragment = new FeedFragment();
                break;

            case R.id.nav_psnn:
                fragment = new TrolleyFragment();
                break;

            case R.id.nav_fav:
                fragment = new FavouriteFragment();
                break;

            case R.id.nav_jual:
                fragment = new TrolleyFragment();
                break;
            case R.id.nav_kategori:
                fragment = new CategoryFragment();
                break;

*/
        }

        if(fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager() .beginTransaction();
            ft.replace(R.id.content_main, fragment);
            ft.commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        displaySelectedScreen(id);
        return true;
    }
}
